// Matrices.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Matriz.h"
#include "iostream"
using namespace std;
void main()
{
  Matriz m1, m2, m3;
  m1.definir();
  m1.mostrar();
  m2.definir();
  m2.mostrar();
  m3.sumarmatrices(m1,m2);
  cout<<"la suma es: "<<endl;
  m3.mostrar();
  system("pause");
}

