#include "StdAfx.h"
#include "Matriz.h"
#include "iostream"
using namespace std;

Matriz::Matriz(void)
{
}
Matriz::~Matriz(void)
{
}
Matriz::Matriz(int _n, int _m)
{
	n=_n;
	m=_m;
}
void Matriz::setFil(int f)
{
  n=f;
}
void Matriz::setCol(int c)
{
  m=c;
}
int Matriz::getFil()
{
  return n;
}
int Matriz::getCol()
{
  return m;
}
void Matriz::setElem(int x,int i, int j)
{
   mat[i][j]=x;
}
int Matriz::getElem(int i, int j)
{
  return mat[i][j];
}
void Matriz::definir()
{
	int f,c,x;
	cout<<"Cantidad filas:";
	cin>>f; 
	cout<<"Cantidad columnas:";
	cin>>c;
	setFil(f);
	setCol(c);
	for(int i=0;i<f;i++)
	{ for(int j=0;j<c;j++)
	  {
        cout<<"Elem:"; cin>>x;
		setElem(x,i,j);
	  }
	}
}
void Matriz::mostrar()
{
	for(int i=0; i<getFil(); i++)
		{
			for(int j=0; j<getCol(); j++)
		  {
			  cout<<getElem(i,j)<<"  ";
          }
			cout<<endl;
        }
}
void Matriz::sumarmatrices(Matriz mat1, Matriz mat2)
{int s=0;
	if( (mat1.getFil()!=mat2.getFil())|| (mat1.getCol()!=mat2.getCol()) )
		{cout<<"dimensiones diferentes,no se puede sumar"<<endl;
        }
	else
		{setCol(mat1.getCol());
         setFil(mat1.getFil());
	       for(int i=0; i<getFil(); i++)
             {
              for(int j=0; j<getCol(); j++)
			   {
				s=mat1.getElem(i,j)+mat2.getElem(i,j);
				setElem(s, i,j);
			   }
             }   
	     }
}